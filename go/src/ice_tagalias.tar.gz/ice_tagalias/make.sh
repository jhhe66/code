g++ -o libice_tagalias.so -shared -fPIC -O2 -Wall -g -I. ice_tagalias.cc tagAlias.cpp
