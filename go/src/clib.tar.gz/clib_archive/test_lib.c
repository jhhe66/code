#include "libgo.h"

int 
main(int argc, char* argv[]) 
{
	GoCall((char *)argv[1]);
    return 0;
}
