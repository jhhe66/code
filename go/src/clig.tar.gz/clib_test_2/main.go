// clib_test_2 project main.go
package main

/*
#include <stdio.h>
*/
import "C"

import (
	"fmt"
)

func main() {
	C.printf(C.CString("hello"))
}
