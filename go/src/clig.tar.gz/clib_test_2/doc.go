// clib_test_2 project doc.go

/*
clib_test_2 document
*/
package main
