// clib_test project doc.go

/*
clib_test document
*/
package main
