# Wrapping C++ with Go

This is a minimal example of how to wrap a C++ class manually with Go.

I borrowed most of the code from [a stack overflow answer](http://stackoverflow.com/questions/1713214/how-to-use-c-in-go),
but modified it to use static linking.

