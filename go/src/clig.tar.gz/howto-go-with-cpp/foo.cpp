#include <iostream>
#include "foo.hpp"

void cxxFoo::Bar(void) {
	std::cout<<this->a<<std::endl;
}

