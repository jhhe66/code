// clib_warper project doc.go

/*
clib_warper document
*/
package clib_warper
