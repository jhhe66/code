#!/bin/sh

g++ -o libice_warper.so ice_warper.cc /root/job/jpush-server-broadcast/interface/QueryUserApi.cpp  -shared -fPIC -I/root/job/jpush-server-broadcast/interface
#ar -rcu libice_warper.a  ice_warper.o
